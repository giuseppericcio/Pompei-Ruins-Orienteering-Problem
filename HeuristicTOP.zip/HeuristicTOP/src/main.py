"""
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Multi-Source Team Orienteering Problem (MSTOP)

The objective of the project is to develop an efficient algorithm to solve this extension
of the classic team orienteering problem, in which the vehicles / paths may start from
several different sources.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
"""

import os
import time
import functools

import utils
import iterators
import solver
from mapper import mapper
from pjs import PJS



if __name__ == "__main__":

    problem = utils.read_single_source("Scavi di Pompei-Siti archeologici.txt")

    alpha = solver.alpha_optimisation(problem)

    solver.set_savings(problem, alpha=alpha)


    print("alpha = " + str(alpha))


    _start = time.time()

    revenue, mapping, routes = solver.heuristic(problem, iterators.greedy, alpha)

    print("Heuristic --> Tempo: " + str(time.time() - _start) + " Punteggio: " + str(revenue))

    utils.plot(problem, mapping=mapping, routes=routes, title="Heuristic")


    """_start = time.time()

    revenue, mapping, routes = solver.multistart(problem, alpha, maxiter=1000, betarange=(0.1, 0.3))

    print("Multistart --> Tempo: " + str(time.time() - _start) + " Punteggio: " + str(revenue))

    utils.plot(problem, mapping=mapping, routes=routes, title="Multistart")


    _start = time.time()

    elite_solutions = solver.multistart_keep_elites(problem, alpha, maxiter=1000, betarange=(0.1, 0.3), nelites=5)

    print("Multistart Elites --> Tempo: " + str(time.time() - _start) + " Punteggio: " + str(revenue))

    utils.plot(problem, mapping=mapping, routes=routes, title="Multistart Elites")


    _start = time.time()

    revenue, mapping, routes = solver.optimise_elites(problem, elite_solutions, alpha, maxiter=3000, betarange=(0.1, 0.3))

    print("Optimise Elites --> Tempo: " + str(time.time() - _start) + " Punteggio: " + str(revenue))

    utils.plot(problem, mapping=mapping, routes=routes, title="Optimise Elites")"""


    print("Program concluded \u2764\uFE0F")
